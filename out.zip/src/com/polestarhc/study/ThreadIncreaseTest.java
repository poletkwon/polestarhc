package com.polestarhc.study;

import java.util.List;

public class ThreadIncreaseTest implements Runnable{

    @Override
    public void run() {
        for(int i = 0 ; i <= 100 ; i++){
//            position++;
//            thread.sleep(200);

        }
    }
}
