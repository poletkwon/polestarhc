package com.polestarhc.study5;

public interface IExcel {
    String getValue(String key);

}
