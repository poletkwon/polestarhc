package com.polestarhc.study;

public interface INotification {
    void notificationCalled();
}
