package com.polestarhc.study6.study.src.com.polestarhc.study;

public class Study {
    private String patientId;
    private String patientName;

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }
}
