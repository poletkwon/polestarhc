package com.polestarhc.study;

public class DecreaseThreadTest implements Runnable{
    private INotification notification;

    public DecreaseThreadTest(INotification notification) {
        this.notification = notification;
    }
    @Override
    public void run() {
        System.out.println("DecreaseThreadTest.run");
        if (notification != null) {
            for (int i=0; i < 100; i++) {
                notification.notificationDecrease();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
