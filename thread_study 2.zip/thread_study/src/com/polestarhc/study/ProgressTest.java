package com.polestarhc.study;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ProgressTest implements INotification {
    private JProgressBar progressBar;
    private JPanel panelProgress;
    private JButton buttonIncress;
    private JButton buttonDecress;

    int position = 0;
    public JPanel getPanel() {
        return panelProgress;
    }

    public ProgressTest() {
        progressBar.setMaximum(100);
        buttonIncress.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                startIncreate();

            }
        });
        buttonDecress.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                startDecrease();
            }
        });
    }

    private void startIncreate() {
        System.out.println("ProgressTest.actionPerformed 눌림");
        Thread increaseThread = new Thread(new IncreaseThreadTest(this));

        // class에서 this를 쓰는 것은 자기 자신 class를 의미한다.

        increaseThread.start();
    }

    private void startDecrease(){
        System.out.println("ProgressTest.actionPerformed 눌림");
        Thread decreaseThread = new Thread(new DecreaseThreadTest(this));

        decreaseThread.start();

    }

    @Override
    public void notificationCalled() {
        System.out.println("ProgressTest.notificationCalled");
        position ++;
            if ( 100 < position) {
                position = 100;
            }
            progressBar.setValue(position);
    }

    @Override
    public void notificationDecrease() {
        System.out.println("ProgressTest.notificationDecrease");
        position --;
        if ( 0 > position) {
            position = 0;
        }
        progressBar.setValue(position);
    }


}
